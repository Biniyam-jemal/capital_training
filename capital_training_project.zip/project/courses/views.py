from django.shortcuts import render, get_object_or_404
from .models import Course, Category


def home(request):
    categories = Category.objects.all()
    featured_courses = Course.objects.filter(is_published=True).order_by('-created_at')[:8]
    return render(request, 'courses/home.html', {
        'categories': categories,
        'featured_courses': featured_courses,
    })


def course_list(request, category_slug=None):
    categories = Category.objects.all()
    courses = Course.objects.filter(is_published=True)

    category = None
    if category_slug:
        category = get_object_or_404(Category, slug=category_slug)
        courses = courses.filter(category=category)

    # simple search
    query = request.GET.get('q')
    if query:
        courses = courses.filter(title__icontains=query)

    return render(request, 'courses/course_list.html', {
        'categories': categories,
        'courses': courses,
        'current_category': category,
        'query': query or '',
    })


def course_detail(request, slug):
    course = get_object_or_404(Course, slug=slug, is_published=True)
    modules = course.modules.prefetch_related('lessons').all()

    is_enrolled = False
    enrollment = None
    if request.user.is_authenticated:
        from enrollments.models import Enrollment
        enrollment = Enrollment.objects.filter(
            student=request.user, course=course, is_active=True
        ).first()
        is_enrolled = enrollment is not None

    return render(request, 'courses/course_detail.html', {
        'course': course,
        'modules': modules,
        'is_enrolled': is_enrolled,
        'enrollment': enrollment,
    })
