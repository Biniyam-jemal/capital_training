from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import StudentRegistrationForm


def register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome to Capital Training! Your account has been created.')
            return redirect('courses:home')
    else:
        form = StudentRegistrationForm()
    return render(request, 'accounts/register.html', {'form': form})


@login_required
def dashboard(request):
    from enrollments.models import Enrollment
    enrollments = Enrollment.objects.filter(student=request.user, is_active=True).select_related('course')
    return render(request, 'accounts/dashboard.html', {'enrollments': enrollments})
